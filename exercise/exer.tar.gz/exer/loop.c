#include<stdio.h>

int main(){

	while(1){
		//do nothing huehuehue
	}

}
